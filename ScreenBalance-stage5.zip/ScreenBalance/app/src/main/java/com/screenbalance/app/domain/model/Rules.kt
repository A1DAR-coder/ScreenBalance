package com.screenbalance.app.domain.model

import java.time.DayOfWeek

/** Per-app rule. Default limit is 60 min/day; [blockedDays] blocks the app completely on those days. */
data class AppLimit(
    val packageName: String,
    val label: String,
    val dailyLimitMin: Int = 60,
    val blockedDays: Set<DayOfWeek> = emptySet(),
    val enabled: Boolean = true
)

/** "After N minutes of total phone use, lock these apps until midnight." */
data class GlobalRule(
    val enabled: Boolean = true,
    val thresholdMin: Int = AppPolicies.DEFAULT_THRESHOLD_MINUTES,
    val lockedPackages: Set<String> = AppPolicies.LOCKED_AFTER_THRESHOLD.values.flatten().toSet()
)

enum class BlockReason { APP_LIMIT, GLOBAL_THRESHOLD, BLOCKED_DAY }

sealed interface BlockDecision {
    data object Allow : BlockDecision
    data class Block(val reason: BlockReason, val limitMin: Int) : BlockDecision
}
