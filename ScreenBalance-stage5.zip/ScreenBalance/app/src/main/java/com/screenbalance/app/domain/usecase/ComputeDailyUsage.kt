package com.screenbalance.app.domain.usecase

import com.screenbalance.app.domain.model.UsageEvent
import com.screenbalance.app.domain.model.UsageEventType
import kotlin.math.max
import kotlin.math.min

data class Interval(val pkg: String, val startMs: Long, val endMs: Long)

data class DailyUsage(
    val perAppMs: Map<String, Long>,
    /** Union of all foreground time, so split-screen overlap isn't double counted. */
    val totalMs: Long,
    val sessionsPerApp: Map<String, Int>
)

/**
 * Turns raw foreground events into per-app and total foreground time inside
 * [windowStartMs, windowEndMs). Pure Kotlin => unit-testable.
 *
 * Rules:
 *  - An app is "in foreground" while at least one of its activities is resumed.
 *  - STOP_ALL (screen off / device shutdown) closes every open session.
 *  - Sessions still open at the window end are counted up to the window end.
 *  - Sessions are clipped to the window, so a session crossing midnight is split.
 */
class ComputeDailyUsage {

    operator fun invoke(
        events: List<UsageEvent>,
        windowStartMs: Long,
        windowEndMs: Long,
        excluded: Set<String> = emptySet()
    ): DailyUsage {
        val intervals = mutableListOf<Interval>()
        val openActivities = HashMap<String, MutableSet<String>>()
        val openedAt = HashMap<String, Long>()

        fun clip(pkg: String, s: Long, e: Long) {
            val a = max(s, windowStartMs)
            val b = min(e, windowEndMs)
            if (b > a) intervals += Interval(pkg, a, b)
        }

        fun close(pkg: String, t: Long) {
            val s = openedAt.remove(pkg) ?: return
            openActivities.remove(pkg)
            clip(pkg, s, t)
        }

        for (ev in events.sortedBy { it.timeMs }) {
            when (ev.type) {
                UsageEventType.RESUMED -> {
                    if (ev.packageName in excluded) continue
                    val set = openActivities.getOrPut(ev.packageName) { mutableSetOf() }
                    if (set.isEmpty()) openedAt[ev.packageName] = ev.timeMs
                    set.add(ev.className)
                }
                UsageEventType.PAUSED -> {
                    val set = openActivities[ev.packageName] ?: continue
                    set.remove(ev.className)
                    if (set.isEmpty()) close(ev.packageName, ev.timeMs)
                }
                UsageEventType.STOP_ALL ->
                    openActivities.keys.toList().forEach { close(it, ev.timeMs) }
            }
        }
        openActivities.keys.toList().forEach { close(it, windowEndMs) }

        val perApp = intervals.groupBy { it.pkg }
            .mapValues { (_, list) -> list.sumOf { it.endMs - it.startMs } }
        val sessions = intervals.groupBy { it.pkg }.mapValues { it.value.size }
        return DailyUsage(perApp, unionLength(intervals), sessions)
    }

    private fun unionLength(intervals: List<Interval>): Long {
        if (intervals.isEmpty()) return 0
        var total = 0L
        var curStart = -1L
        var curEnd = -1L
        for (i in intervals.sortedBy { it.startMs }) {
            if (curEnd < 0) { curStart = i.startMs; curEnd = i.endMs }
            else if (i.startMs <= curEnd) curEnd = max(curEnd, i.endMs)
            else { total += curEnd - curStart; curStart = i.startMs; curEnd = i.endMs }
        }
        return total + (curEnd - curStart)
    }
}
