package com.screenbalance.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.screenbalance.app.ScreenBalanceApp
import com.screenbalance.app.platform.accessibility.AccessibilityStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class HomeUiState(
    val usageAccess: Boolean = false,
    val blockerEnabled: Boolean = false,
    val totalMin: Int = 0,
    val thresholdMin: Int = 45,
    val ruleEnabled: Boolean = true,
    val topApps: List<Pair<String, Int>> = emptyList()
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val c = (app as ScreenBalanceApp).container
    private val _state = MutableStateFlow(HomeUiState())
    val state: StateFlow<HomeUiState> = _state

    fun refresh() {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val pm = ctx.packageManager
            fun label(p: String) = runCatching { pm.getApplicationInfo(p, 0).loadLabel(pm).toString() }.getOrDefault(p)
            val global = c.settings.globalRule.first()
            val snap = c.usageRepo.snapshotToday()
            _state.value = HomeUiState(
                usageAccess = c.usageReader.hasPermission(),
                blockerEnabled = AccessibilityStatus.isBlockerEnabled(ctx),
                totalMin = (snap.usage.totalMs / 60_000).toInt(),
                thresholdMin = global.thresholdMin,
                ruleEnabled = global.enabled,
                topApps = snap.usage.perAppMs.entries.sortedByDescending { it.value }.take(5)
                    .map { label(it.key) to (it.value / 60_000).toInt() }
            )
        }
    }

    fun changeThreshold(delta: Int) {
        viewModelScope.launch {
            val cur = c.settings.globalRule.first().thresholdMin
            c.settings.setThreshold((cur + delta).coerceIn(1, 480))
            refresh()
        }
    }

    fun setRuleEnabled(on: Boolean) {
        viewModelScope.launch { c.settings.setGlobalEnabled(on); refresh() }
    }
}
