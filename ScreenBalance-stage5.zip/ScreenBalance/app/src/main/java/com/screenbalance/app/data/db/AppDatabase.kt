package com.screenbalance.app.data.db

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [AppLimitEntity::class, DailyUsageEntity::class], version = 1, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appLimitDao(): AppLimitDao
    abstract fun dailyUsageDao(): DailyUsageDao
}
