package com.screenbalance.app.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.screenbalance.app.domain.model.AppPolicies
import com.screenbalance.app.domain.model.GlobalRule
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class SettingsStore(private val context: Context) {
    private object K {
        val enabled = booleanPreferencesKey("global_enabled")
        val threshold = intPreferencesKey("global_threshold_min")
        val locked = stringSetPreferencesKey("global_locked_packages")
    }

    private val defaults = GlobalRule()

    val globalRule: Flow<GlobalRule> = context.dataStore.data.map { p ->
        GlobalRule(
            enabled = p[K.enabled] ?: defaults.enabled,
            thresholdMin = p[K.threshold] ?: AppPolicies.DEFAULT_THRESHOLD_MINUTES,
            lockedPackages = p[K.locked] ?: defaults.lockedPackages
        )
    }

    suspend fun setGlobalEnabled(on: Boolean) { context.dataStore.edit { it[K.enabled] = on } }
    suspend fun setThreshold(min: Int) { context.dataStore.edit { it[K.threshold] = min } }
    suspend fun setLockedPackages(pkgs: Set<String>) {
        // Safety: protected apps can never be added to the locked list.
        context.dataStore.edit { it[K.locked] = pkgs - AppPolicies.NEVER_BLOCK }
    }
}
