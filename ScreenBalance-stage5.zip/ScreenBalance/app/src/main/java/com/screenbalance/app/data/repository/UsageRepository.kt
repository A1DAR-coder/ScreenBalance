package com.screenbalance.app.data.repository

import com.screenbalance.app.data.db.DailyUsageDao
import com.screenbalance.app.data.db.DailyUsageEntity
import com.screenbalance.app.domain.model.AppPolicies
import com.screenbalance.app.domain.usecase.ComputeDailyUsage
import com.screenbalance.app.domain.usecase.DailyUsage
import com.screenbalance.app.domain.usecase.DayWindows
import com.screenbalance.app.platform.usage.UsageStatsReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.ZoneId

data class TodaySnapshot(val date: LocalDate, val usage: DailyUsage)

/**
 * Source of truth for usage = the system's UsageStats events (they survive clearing our app data
 * and rebooting). Room stores a copy of the daily totals for statistics and as a fallback when
 * the Usage Access permission is missing.
 */
class UsageRepository(
    private val reader: UsageStatsReader,
    private val dao: DailyUsageDao,
    private val compute: ComputeDailyUsage = ComputeDailyUsage(),
    private val zoneProvider: () -> ZoneId = { ZoneId.systemDefault() }
) {
    suspend fun snapshotToday(nowMs: Long = System.currentTimeMillis()): TodaySnapshot =
        withContext(Dispatchers.IO) {
            val w = DayWindows.of(nowMs, zoneProvider())
            if (!reader.hasPermission()) return@withContext fromStored(w.date)
            // Look back 12h so a session that started before midnight is seen (it gets clipped to today).
            val events = reader.readEvents(w.startMs - LOOKBACK_MS, w.endMs)
            TodaySnapshot(w.date, compute(events, w.startMs, w.endMs, AppPolicies.EXCLUDED_FROM_TOTAL))
        }

    /** Takes a snapshot and saves it. Never overwrites stored data when permission is missing. */
    suspend fun persistToday(nowMs: Long = System.currentTimeMillis()): TodaySnapshot {
        val s = snapshotToday(nowMs)
        if (!reader.hasPermission()) return s
        val day = s.date.toString()
        val rows = s.usage.perAppMs.map { (p, ms) ->
            DailyUsageEntity(day, p, ms, s.usage.sessionsPerApp[p] ?: 0)
        } + DailyUsageEntity(day, TOTAL_KEY, s.usage.totalMs, s.usage.sessionsPerApp.values.sum())
        withContext(Dispatchers.IO) { dao.upsertAll(rows) }
        return s
    }

    private suspend fun fromStored(date: LocalDate): TodaySnapshot {
        val rows = dao.forDay(date.toString())
        val apps = rows.filter { it.packageName != TOTAL_KEY }
        return TodaySnapshot(
            date,
            DailyUsage(
                perAppMs = apps.associate { it.packageName to it.usedMs },
                totalMs = rows.firstOrNull { it.packageName == TOTAL_KEY }?.usedMs ?: 0L,
                sessionsPerApp = apps.associate { it.packageName to it.sessions }
            )
        )
    }

    companion object {
        const val TOTAL_KEY = "__total__"
        private const val LOOKBACK_MS = 12 * 60 * 60 * 1000L
    }
}
