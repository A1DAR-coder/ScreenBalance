package com.screenbalance.app.domain.model

/** Platform-independent usage event so the maths can be unit-tested without Android. */
enum class UsageEventType { RESUMED, PAUSED, STOP_ALL }

data class UsageEvent(
    val packageName: String,
    val className: String,
    val type: UsageEventType,
    val timeMs: Long
)
