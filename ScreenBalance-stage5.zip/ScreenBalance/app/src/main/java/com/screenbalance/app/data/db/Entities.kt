package com.screenbalance.app.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.screenbalance.app.domain.model.AppLimit
import java.time.DayOfWeek

@Entity(tableName = "app_limits")
data class AppLimitEntity(
    @PrimaryKey val packageName: String,
    val label: String,
    val dailyLimitMin: Int,
    val blockedDaysMask: Int,
    val enabled: Boolean
) {
    fun toDomain() = AppLimit(packageName, label, dailyLimitMin, maskToDays(blockedDaysMask), enabled)

    companion object {
        fun from(l: AppLimit) = AppLimitEntity(l.packageName, l.label, l.dailyLimitMin, daysToMask(l.blockedDays), l.enabled)
        fun daysToMask(days: Set<DayOfWeek>) = days.fold(0) { acc, d -> acc or (1 shl (d.value - 1)) }
        fun maskToDays(mask: Int): Set<DayOfWeek> =
            DayOfWeek.values().filter { mask and (1 shl (it.value - 1)) != 0 }.toSet()
    }
}

/** One row per (date, app). packageName "__total__" holds the day's total phone time. */
@Entity(tableName = "daily_usage", primaryKeys = ["day", "packageName"])
data class DailyUsageEntity(
    val day: String,          // ISO date, e.g. 2026-10-04 (sorts correctly as text)
    val packageName: String,
    val usedMs: Long,
    val sessions: Int
)
