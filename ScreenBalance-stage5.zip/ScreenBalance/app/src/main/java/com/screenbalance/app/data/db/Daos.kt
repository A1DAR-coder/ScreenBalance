package com.screenbalance.app.data.db

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface AppLimitDao {
    @Query("SELECT * FROM app_limits") fun observeAll(): Flow<List<AppLimitEntity>>
    @Query("SELECT * FROM app_limits") suspend fun getAll(): List<AppLimitEntity>
    @Upsert suspend fun upsert(entity: AppLimitEntity)
    @Query("DELETE FROM app_limits WHERE packageName = :pkg") suspend fun delete(pkg: String)
}

@Dao
interface DailyUsageDao {
    @Upsert suspend fun upsertAll(items: List<DailyUsageEntity>)
    @Query("SELECT * FROM daily_usage WHERE day = :day") suspend fun forDay(day: String): List<DailyUsageEntity>
    @Query("SELECT * FROM daily_usage WHERE day BETWEEN :from AND :to")
    fun observeRange(from: String, to: String): Flow<List<DailyUsageEntity>>
}
