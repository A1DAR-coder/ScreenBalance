package com.screenbalance.app.data.repository

import com.screenbalance.app.data.db.AppLimitDao
import com.screenbalance.app.data.db.AppLimitEntity
import com.screenbalance.app.domain.model.AppLimit
import com.screenbalance.app.domain.model.AppPolicies
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LimitsRepository(private val dao: AppLimitDao) {
    fun observe(): Flow<List<AppLimit>> = dao.observeAll().map { list -> list.map { it.toDomain() } }
    suspend fun getMap(): Map<String, AppLimit> = dao.getAll().associate { it.packageName to it.toDomain() }

    suspend fun save(limit: AppLimit) {
        require(!AppPolicies.isProtected(limit.packageName)) { "Protected apps cannot be limited" }
        dao.upsert(AppLimitEntity.from(limit))
    }
    suspend fun remove(pkg: String) = dao.delete(pkg)
}
