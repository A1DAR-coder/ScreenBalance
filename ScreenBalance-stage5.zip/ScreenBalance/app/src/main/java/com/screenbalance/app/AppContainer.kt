package com.screenbalance.app

import android.content.Context
import androidx.room.Room
import com.screenbalance.app.data.db.AppDatabase
import com.screenbalance.app.data.prefs.SettingsStore
import com.screenbalance.app.data.repository.LimitsRepository
import com.screenbalance.app.data.repository.UsageRepository
import com.screenbalance.app.domain.usecase.EvaluateBlock
import com.screenbalance.app.platform.usage.UsageStatsReader

/** Tiny manual dependency container (no DI framework needed for an app this size). */
class AppContainer(context: Context) {
    private val app = context.applicationContext
    val db: AppDatabase by lazy { Room.databaseBuilder(app, AppDatabase::class.java, "screenbalance.db").build() }
    val settings by lazy { SettingsStore(app) }
    val usageReader by lazy { UsageStatsReader(app) }
    val limitsRepo by lazy { LimitsRepository(db.appLimitDao()) }
    val usageRepo by lazy { UsageRepository(usageReader, db.dailyUsageDao()) }
    val evaluateBlock = EvaluateBlock()
}
