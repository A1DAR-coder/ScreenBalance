package com.screenbalance.app.platform.usage

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process
import com.screenbalance.app.domain.model.UsageEvent
import com.screenbalance.app.domain.model.UsageEventType

/** Reads foreground events from the official UsageStatsManager. Read-only; cannot block anything. */
class UsageStatsReader(private val context: Context) {

    /** "Usage data access" is a special permission, checked via AppOps (not runtime-grantable). */
    fun hasPermission(): Boolean {
        val ops = context.getSystemService(AppOpsManager::class.java)
        val mode = ops.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun readEvents(fromMs: Long, toMs: Long): List<UsageEvent> {
        if (!hasPermission()) return emptyList()
        val usm = context.getSystemService(UsageStatsManager::class.java)
        val raw = usm.queryEvents(fromMs, toMs)
        val e = UsageEvents.Event()
        val out = ArrayList<UsageEvent>()
        while (raw.hasNextEvent()) {
            raw.getNextEvent(e)
            val type = when (e.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> UsageEventType.RESUMED
                UsageEvents.Event.ACTIVITY_PAUSED -> UsageEventType.PAUSED
                UsageEvents.Event.SCREEN_NON_INTERACTIVE,
                UsageEvents.Event.DEVICE_SHUTDOWN -> UsageEventType.STOP_ALL
                else -> null
            } ?: continue
            out += UsageEvent(e.packageName ?: "", e.className ?: "", type, e.timeStamp)
        }
        return out
    }

    /** Which app is in front right now (used after screen-on/unlock, when no window event may fire). */
    fun currentForegroundPackage(nowMs: Long): String? {
        var cur: Pair<String, String>? = null
        for (ev in readEvents(nowMs - 5 * 60_000L, nowMs)) {
            when (ev.type) {
                UsageEventType.RESUMED -> cur = ev.packageName to ev.className
                UsageEventType.PAUSED -> if (cur == ev.packageName to ev.className) cur = null
                UsageEventType.STOP_ALL -> cur = null
            }
        }
        return cur?.first
    }
}
