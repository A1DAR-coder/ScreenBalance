package com.screenbalance.app.domain.usecase

import com.screenbalance.app.domain.model.*
import java.time.DayOfWeek

/**
 * Decides whether an app must be blocked right now. Pure function => easy to test.
 * Order of checks (first match wins):
 *  1. Protected apps (WhatsApp, calls, system) and our own app are NEVER blocked.
 *  2. Per-app rule: blocked day, then daily limit.
 *  3. Global rule: total phone time >= threshold AND app is in the locked list.
 */
class EvaluateBlock {

    operator fun invoke(
        pkg: String,
        usage: DailyUsage,
        limits: Map<String, AppLimit>,
        global: GlobalRule,
        today: DayOfWeek
    ): BlockDecision {
        if (pkg == AppPolicies.OWN_PACKAGE || AppPolicies.isProtected(pkg)) return BlockDecision.Allow

        val limit = limits[pkg]?.takeIf { it.enabled }
        if (limit != null) {
            if (today in limit.blockedDays) return BlockDecision.Block(BlockReason.BLOCKED_DAY, 0)
            val used = usage.perAppMs[pkg] ?: 0L
            if (used >= limit.dailyLimitMin * MIN) return BlockDecision.Block(BlockReason.APP_LIMIT, limit.dailyLimitMin)
        }
        if (global.enabled && pkg in global.lockedPackages && usage.totalMs >= global.thresholdMin * MIN) {
            return BlockDecision.Block(BlockReason.GLOBAL_THRESHOLD, global.thresholdMin)
        }
        return BlockDecision.Allow
    }

    /** Milliseconds of use left before [pkg] gets blocked; null = this app has no limit. */
    fun remainingMs(
        pkg: String,
        usage: DailyUsage,
        limits: Map<String, AppLimit>,
        global: GlobalRule,
        today: DayOfWeek
    ): Long? {
        if (pkg == AppPolicies.OWN_PACKAGE || AppPolicies.isProtected(pkg)) return null
        val limit = limits[pkg]?.takeIf { it.enabled }
        var best: Long? = null
        if (limit != null) {
            if (today in limit.blockedDays) return 0L
            best = (limit.dailyLimitMin * MIN - (usage.perAppMs[pkg] ?: 0L)).coerceAtLeast(0L)
        }
        if (global.enabled && pkg in global.lockedPackages) {
            val r = (global.thresholdMin * MIN - usage.totalMs).coerceAtLeast(0L)
            best = if (best == null) r else minOf(best, r)
        }
        return best
    }

    private companion object { const val MIN = 60_000L }
}
