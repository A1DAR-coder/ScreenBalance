package com.screenbalance.app.platform.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.screenbalance.app.platform.work.RefreshUsageWorker

/**
 * After reboot / app update there is nothing to "restore": rules live in Room/DataStore and usage is
 * recomputed from the system's UsageStats. Android restarts an enabled AccessibilityService by itself.
 * We just re-arm the periodic worker and refresh once.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        RefreshUsageWorker.schedule(context)
        RefreshUsageWorker.runOnce(context)
    }
}
