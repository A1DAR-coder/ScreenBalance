package com.screenbalance.app.platform.work

import android.content.Context
import androidx.work.*
import com.screenbalance.app.ScreenBalanceApp
import java.util.concurrent.TimeUnit

/** Saves today's totals to Room (for statistics + permission-loss fallback). WorkManager survives reboots. */
class RefreshUsageWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val container = (applicationContext as ScreenBalanceApp).container
        return try {
            container.usageRepo.persistToday()
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        private const val PERIODIC = "refresh_usage_periodic"

        fun schedule(context: Context) {
            val req = PeriodicWorkRequestBuilder<RefreshUsageWorker>(15, TimeUnit.MINUTES).build()
            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork(PERIODIC, ExistingPeriodicWorkPolicy.KEEP, req)
        }

        fun runOnce(context: Context) {
            WorkManager.getInstance(context).enqueue(OneTimeWorkRequestBuilder<RefreshUsageWorker>().build())
        }
    }
}
