package com.screenbalance.app.ui

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.screenbalance.app.ui.theme.ScreenBalanceTheme

/** Temporary single screen for Stages 4-5: setup status, live usage, and the 45-minute rule. Full UI comes in Stage 7. */
class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ScreenBalanceTheme { HomeScreen(vm) } }
    }

    override fun onResume() {
        super.onResume()
        vm.refresh()
    }
}

@Composable
private fun HomeScreen(vm: MainViewModel) {
    val s by vm.state.collectAsState()
    val ctx = LocalContext.current

    Scaffold { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("ScreenBalance", style = MaterialTheme.typography.headlineMedium)

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Setup", style = MaterialTheme.typography.titleMedium)
                    SetupRow("Usage access", s.usageAccess) {
                        ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                    }
                    SetupRow("App blocker (Accessibility)", s.blockerEnabled) {
                        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }
                    if (!s.blockerEnabled) {
                        Text(
                            "Android 13+: if the switch is greyed out, open Settings → Apps → ScreenBalance → ⋮ → " +
                                "Allow restricted settings, then try again.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Phone-time rule", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        Switch(checked = s.ruleEnabled, onCheckedChange = vm::setRuleEnabled)
                    }
                    Text("After ${s.thresholdMin} min of total phone use today, Telegram, Google, Chrome, Samsung Internet, " +
                        "Netflix, Investing.com, Spotify, YouTube Music and Google TV are locked until midnight. " +
                        "WhatsApp and calls are never blocked.", style = MaterialTheme.typography.bodySmall)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(onClick = { vm.changeThreshold(-5) }) { Text("−5") }
                        OutlinedButton(onClick = { vm.changeThreshold(-1) }) { Text("−1") }
                        Text("${s.thresholdMin} min", style = MaterialTheme.typography.titleMedium)
                        OutlinedButton(onClick = { vm.changeThreshold(1) }) { Text("+1") }
                        OutlinedButton(onClick = { vm.changeThreshold(5) }) { Text("+5") }
                    }
                }
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Today", style = MaterialTheme.typography.titleMedium)
                    Text("Total phone time: ${s.totalMin} min", style = MaterialTheme.typography.bodyLarge)
                    s.topApps.forEach { (name, min) -> Text("$name — $min min", style = MaterialTheme.typography.bodyMedium) }
                }
            }
        }
    }
}

@Composable
private fun SetupRow(label: String, done: Boolean, onFix: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text((if (done) "✅ " else "⚠️ ") + label, modifier = Modifier.weight(1f))
        if (!done) Button(onClick = onFix) { Text("Enable") }
    }
}
