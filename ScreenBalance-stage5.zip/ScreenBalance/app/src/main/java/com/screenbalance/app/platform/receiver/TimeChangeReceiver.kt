package com.screenbalance.app.platform.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.screenbalance.app.platform.work.RefreshUsageWorker

/** Clock / time-zone / date change: "today" is recomputed on every evaluation; we just refresh the saved copy. */
class TimeChangeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        RefreshUsageWorker.runOnce(context)
    }
}
