package com.screenbalance.app

import android.app.Application
import com.screenbalance.app.platform.work.RefreshUsageWorker

class ScreenBalanceApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        RefreshUsageWorker.schedule(this)
    }
}
