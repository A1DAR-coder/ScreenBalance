package com.screenbalance.app.platform.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import androidx.core.content.ContextCompat
import com.screenbalance.app.ScreenBalanceApp
import com.screenbalance.app.domain.model.AppPolicies
import com.screenbalance.app.domain.model.BlockDecision
import com.screenbalance.app.platform.work.RefreshUsageWorker
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import java.util.concurrent.CancellationException

/**
 * Enforcement. Only learns WHICH app is in front (canRetrieveWindowContent=false: no screen content).
 *
 * Efficiency: nothing runs while a non-limited app is open. While a limited app is in front, a loop
 * re-checks usage every <=15 s and exactly when the remaining time runs out.
 */
class BlockerAccessibilityService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val main = Handler(Looper.getMainLooper())
    private var monitorJob: Job? = null
    private var currentPkg: String? = null
    private var lastBlockAt = 0L
    private var imePackages: Set<String> = emptySet()
    private var receiverRegistered = false
    private val container get() = (applicationContext as ScreenBalanceApp).container

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> { monitorJob?.cancel(); currentPkg = null }
                Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> redetectForeground()
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        running = true
        refreshImePackages()
        if (!receiverRegistered) {
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_USER_PRESENT)
            }
            ContextCompat.registerReceiver(this, screenReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
            receiverRegistered = true
        }
        RefreshUsageWorker.runOnce(this)
        redetectForeground()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return

        if (pkg == packageName) {            // our own UI (incl. block screen): stop monitoring, forget last app
            monitorJob?.cancel()
            currentPkg = null
            return
        }
        if (!shouldTrack(pkg) || pkg == currentPkg) return
        currentPkg = pkg
        onForegroundChanged(pkg)
    }

    private fun shouldTrack(pkg: String) =
        pkg != packageName && pkg !in IGNORED && pkg !in imePackages

    private fun onForegroundChanged(pkg: String) {
        monitorJob?.cancel()
        if (AppPolicies.isProtected(pkg)) return   // WhatsApp, calls, launcher, settings: never touched

        monitorJob = scope.launch {
            while (isActive) {
                try {
                    val snap = container.usageRepo.snapshotToday()
                    val limits = container.limitsRepo.getMap()
                    val global = container.settings.globalRule.first()
                    val day = snap.date.dayOfWeek

                    val decision = container.evaluateBlock(pkg, snap.usage, limits, global, day)
                    if (decision is BlockDecision.Block) {
                        withContext(Dispatchers.Main) { block(pkg, decision) }
                        break
                    }
                    val remaining = container.evaluateBlock.remainingMs(pkg, snap.usage, limits, global, day)
                        ?: break                    // app has no limit: no need to keep polling
                    delay(remaining.coerceIn(1_000L, 15_000L))
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.e(TAG, "evaluation failed", e)
                    break
                }
            }
        }
    }

    /** Kick the app to Home, then show the full-screen block activity. */
    private fun block(pkg: String, d: BlockDecision.Block) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastBlockAt < 1_000L) return
        lastBlockAt = now

        performGlobalAction(GLOBAL_ACTION_HOME)   // fallback: even if the activity can't start, the app is closed
        main.postDelayed({
            val intent = Intent(this, BlockActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                .putExtra(BlockActivity.EXTRA_PACKAGE, pkg)
                .putExtra(BlockActivity.EXTRA_REASON, d.reason.name)
                .putExtra(BlockActivity.EXTRA_LIMIT_MIN, d.limitMin)
            try { startActivity(intent) } catch (e: Exception) { Log.w(TAG, "could not show block screen", e) }
        }, 150)
    }

    private fun redetectForeground() {
        scope.launch {
            delay(600)
            val pkg = container.usageReader.currentForegroundPackage(System.currentTimeMillis()) ?: return@launch
            withContext(Dispatchers.Main) {
                if (shouldTrack(pkg) && pkg != currentPkg) {
                    currentPkg = pkg
                    onForegroundChanged(pkg)
                }
            }
        }
    }

    private fun refreshImePackages() {
        val imm = getSystemService(InputMethodManager::class.java)
        imePackages = imm?.enabledInputMethodList?.map { it.packageName }?.toSet().orEmpty()
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        running = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        running = false
        monitorJob?.cancel()
        scope.cancel()
        if (receiverRegistered) {
            runCatching { unregisterReceiver(screenReceiver) }
            receiverRegistered = false
        }
        super.onDestroy()
    }

    companion object {
        private const val TAG = "Blocker"
        /** Windows that must not be mistaken for "the foreground app changed". */
        private val IGNORED = setOf("com.android.systemui", "android")
        @Volatile var running = false
    }
}
