package com.screenbalance.app.domain.usecase

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

data class DayWindow(val date: LocalDate, val startMs: Long, val endMs: Long)

/**
 * "Today" is always recomputed from the current zone, so there is no midnight job:
 * when the date changes, the window starts at 00:00 and usage is simply zero again.
 * atStartOfDay(zone) is DST-safe (days can be 23 or 25 hours long).
 */
object DayWindows {
    fun of(nowMs: Long, zone: ZoneId): DayWindow {
        val date = Instant.ofEpochMilli(nowMs).atZone(zone).toLocalDate()
        val start = date.atStartOfDay(zone).toInstant().toEpochMilli()
        return DayWindow(date, start, nowMs)
    }
}
