package com.screenbalance.app.platform.accessibility

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.screenbalance.app.domain.model.BlockReason
import com.screenbalance.app.ui.theme.ScreenBalanceTheme

/** Full-screen "Daily limit reached" screen. Back or the button sends the user Home. */
class BlockActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { goHome() }
        })
        render(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        render(intent)
    }

    private fun render(i: Intent) {
        val pkg = i.getStringExtra(EXTRA_PACKAGE).orEmpty()
        val reason = runCatching { BlockReason.valueOf(i.getStringExtra(EXTRA_REASON).orEmpty()) }
            .getOrDefault(BlockReason.APP_LIMIT)
        val limit = i.getIntExtra(EXTRA_LIMIT_MIN, 60)
        val label = appLabel(pkg)

        val (title, message) = when (reason) {
            BlockReason.APP_LIMIT ->
                "Daily limit reached" to "You've used your $limit minutes for $label."
            BlockReason.GLOBAL_THRESHOLD ->
                "Phone time limit reached" to
                    "You've used your $limit minutes of phone time today, so $label is locked until midnight.\n\nWhatsApp and calls still work."
            BlockReason.BLOCKED_DAY ->
                "Not available today" to "$label is blocked today."
        }
        setContent { ScreenBalanceTheme { BlockScreen(title, message) { goHome() } } }
    }

    private fun appLabel(pkg: String): String = runCatching {
        packageManager.getApplicationInfo(pkg, 0).loadLabel(packageManager).toString()
    }.getOrDefault(pkg.ifEmpty { "this app" })

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finishAndRemoveTask()
    }

    companion object {
        const val EXTRA_PACKAGE = "pkg"
        const val EXTRA_REASON = "reason"
        const val EXTRA_LIMIT_MIN = "limit_min"
    }
}

@Composable
private fun BlockScreen(title: String, message: String, onHome: () -> Unit) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("⏳", fontSize = 64.sp)
            Spacer(Modifier.height(24.dp))
            Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            Text(message, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
            Spacer(Modifier.height(32.dp))
            Button(onClick = onHome) { Text("Go home") }
        }
    }
}
