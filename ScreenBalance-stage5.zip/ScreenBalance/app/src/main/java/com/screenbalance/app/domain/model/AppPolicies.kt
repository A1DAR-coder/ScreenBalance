package com.screenbalance.app.domain.model

/**
 * Default package names. Package names can differ by app version/region, so the
 * UI lets the user review and edit these lists (verify with the app picker).
 */
object AppPolicies {

    /** Hard safety list: these are NEVER blocked by any rule, schedule or setting. */
    val NEVER_BLOCK: Set<String> = setOf(
        // WhatsApp (calling your parents)
        "com.whatsapp", "com.whatsapp.w4b",
        // Phone / dialer / in-call UI / emergency
        "com.samsung.android.dialer", "com.samsung.android.incallui",
        "com.google.android.dialer", "com.android.dialer",
        "com.android.server.telecom", "com.android.phone",
        "com.android.emergency", "com.samsung.android.app.telephonyui",
        // System pieces that must always stay reachable
        "com.android.systemui", "com.sec.android.app.launcher",
        "com.android.settings", "com.samsung.android.messaging",
        "com.android.packageinstaller", "com.google.android.permissioncontroller"
    )

    /** Locked once total daily phone time passes the threshold (default 45 min). */
    val LOCKED_AFTER_THRESHOLD: Map<String, Set<String>> = mapOf(
        "Telegram" to setOf("org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram"),
        "Google" to setOf("com.google.android.googlequicksearchbox"),
        "Chrome" to setOf("com.android.chrome"),
        "Samsung Internet" to setOf("com.sec.android.app.sbrowser"),
        "Netflix" to setOf("com.netflix.mediaclient"),
        "Investing.com" to setOf("com.fusionmedia.investing"),
        "Spotify" to setOf("com.spotify.music"),
        "YouTube Music" to setOf("com.google.android.apps.youtube.music"),
        "Google TV" to setOf("com.google.android.videos")
    )

    const val DEFAULT_THRESHOLD_MINUTES = 45
    const val OWN_PACKAGE = "com.screenbalance.app"

    /** Not counted toward total phone time (own app, phone calls, home screen, system UI). */
    val EXCLUDED_FROM_TOTAL: Set<String> = setOf(OWN_PACKAGE, "com.sec.android.app.launcher", "com.android.systemui") +
        NEVER_BLOCK.filter { it.contains("dialer") || it.contains("incallui") || it.contains("telecom") || it.endsWith(".phone") }

    fun isProtected(packageName: String) = packageName in NEVER_BLOCK
}
