package com.screenbalance.app

import com.screenbalance.app.domain.model.AppPolicies
import com.screenbalance.app.domain.model.UsageEvent
import com.screenbalance.app.domain.model.UsageEventType.*
import com.screenbalance.app.domain.usecase.ComputeDailyUsage
import org.junit.Assert.*
import org.junit.Test

class ComputeDailyUsageTest {
    private val min = 60_000L
    private val day = 24 * 60 * min
    private val uc = ComputeDailyUsage()
    private fun ev(p: String, t: com.screenbalance.app.domain.model.UsageEventType, at: Long, c: String = "A") =
        UsageEvent(p, c, t, at)

    @Test fun sixtyMinutesCounted() {
        val r = uc(listOf(ev("yt", RESUMED, 0), ev("yt", PAUSED, 60 * min)), 0, day)
        assertEquals(60 * min, r.perAppMs["yt"])
    }

    @Test fun fiftyNineMinutesIsNotYetLimit() {
        val r = uc(listOf(ev("yt", RESUMED, 0), ev("yt", PAUSED, 59 * min)), 0, day)
        assertEquals(59 * min, r.totalMs)
    }

    @Test fun backgroundTimeNotCounted() {
        val r = uc(listOf(ev("yt", RESUMED, 0), ev("yt", PAUSED, 10 * min),
            ev("yt", RESUMED, 100 * min), ev("yt", PAUSED, 105 * min)), 0, day)
        assertEquals(15 * min, r.perAppMs["yt"])
        assertEquals(2, r.sessionsPerApp["yt"])
    }

    @Test fun sessionAcrossMidnightIsSplit() {
        val r = uc(listOf(ev("yt", RESUMED, day - 10 * min), ev("yt", PAUSED, day + 20 * min)), day, 2 * day)
        assertEquals(20 * min, r.perAppMs["yt"])
    }

    @Test fun splitScreenOverlapNotDoubleCounted() {
        val r = uc(listOf(ev("a", RESUMED, 0), ev("b", RESUMED, 5 * min),
            ev("a", PAUSED, 10 * min), ev("b", PAUSED, 15 * min)), 0, day)
        assertEquals(15 * min, r.totalMs)
        assertEquals(10 * min, r.perAppMs["a"])
    }

    @Test fun screenOffClosesSession() {
        val r = uc(listOf(ev("a", RESUMED, 0), ev("", STOP_ALL, 7 * min)), 0, day)
        assertEquals(7 * min, r.totalMs)
    }

    @Test fun ownAppAndExcludedNotCounted() {
        val r = uc(listOf(ev(AppPolicies.OWN_PACKAGE, RESUMED, 0), ev(AppPolicies.OWN_PACKAGE, PAUSED, 30 * min)),
            0, day, AppPolicies.EXCLUDED_FROM_TOTAL)
        assertEquals(0L, r.totalMs)
    }

    @Test fun openSessionCountsUpToNow() {
        val r = uc(listOf(ev("a", RESUMED, 0)), 0, 12 * min)
        assertEquals(12 * min, r.totalMs)
    }

    @Test fun whatsAppAndDialerAreNeverBlocked() {
        assertTrue(AppPolicies.isProtected("com.whatsapp"))
        assertTrue(AppPolicies.isProtected("com.samsung.android.dialer"))
        assertFalse(AppPolicies.isProtected("org.telegram.messenger"))
    }

    @Test fun lockedListNeverOverlapsProtectedList() {
        val locked = AppPolicies.LOCKED_AFTER_THRESHOLD.values.flatten().toSet()
        assertTrue(locked.intersect(AppPolicies.NEVER_BLOCK).isEmpty())
    }
}
