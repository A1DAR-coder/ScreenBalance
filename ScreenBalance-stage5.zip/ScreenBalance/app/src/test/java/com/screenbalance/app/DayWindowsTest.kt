package com.screenbalance.app

import com.screenbalance.app.domain.usecase.DayWindows
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class DayWindowsTest {
    @Test fun midnightStartsNewDayWithZeroWindow() {
        val zone = ZoneId.of("UTC")
        val before = DayWindows.of(Instant.parse("2026-10-04T23:59:59Z").toEpochMilli(), zone)
        val after = DayWindows.of(Instant.parse("2026-10-05T00:00:01Z").toEpochMilli(), zone)
        assertEquals(LocalDate.of(2026, 10, 4), before.date)
        assertEquals(LocalDate.of(2026, 10, 5), after.date)
        assertEquals(1_000L, after.endMs - after.startMs)
    }

    @Test fun daylightSavingDayIs23Hours() {
        val zone = ZoneId.of("Europe/Berlin")   // clocks jump forward on 2025-03-30
        val a = DayWindows.of(Instant.parse("2025-03-30T12:00:00Z").toEpochMilli(), zone)
        val b = DayWindows.of(Instant.parse("2025-03-31T12:00:00Z").toEpochMilli(), zone)
        assertEquals(23 * 3_600_000L, b.startMs - a.startMs)
    }

    @Test fun timeZoneChangeChangesTheDate() {
        val t = Instant.parse("2026-06-01T23:30:00Z").toEpochMilli()
        assertEquals(LocalDate.of(2026, 6, 1), DayWindows.of(t, ZoneId.of("UTC")).date)
        assertEquals(LocalDate.of(2026, 6, 2), DayWindows.of(t, ZoneId.of("Asia/Tokyo")).date)
    }
}
