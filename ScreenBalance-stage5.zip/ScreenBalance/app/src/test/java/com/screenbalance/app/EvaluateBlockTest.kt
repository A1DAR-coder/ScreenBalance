package com.screenbalance.app

import com.screenbalance.app.domain.model.*
import com.screenbalance.app.domain.usecase.DailyUsage
import com.screenbalance.app.domain.usecase.EvaluateBlock
import org.junit.Assert.*
import org.junit.Test
import java.time.DayOfWeek

class EvaluateBlockTest {
    private val min = 60_000L
    private val eval = EvaluateBlock()
    private val global = GlobalRule()
    private val mon = DayOfWeek.MONDAY
    private val yt = "com.google.android.youtube"
    private val insta = "com.instagram.android"

    private fun usage(totalMin: Int, vararg per: Pair<String, Int>) =
        DailyUsage(per.associate { it.first to it.second * min }, totalMin * min, emptyMap())
    private fun limit(pkg: String, m: Int = 60, days: Set<DayOfWeek> = emptySet()) =
        pkg to AppLimit(pkg, pkg, m, days)

    @Test fun at59MinutesStillAllowed() {
        val d = eval(yt, usage(59, yt to 59), mapOf(limit(yt)), global, mon)
        assertEquals(BlockDecision.Allow, d)
    }

    @Test fun at60MinutesBlocked() {
        val d = eval(yt, usage(60, yt to 60), mapOf(limit(yt)), global, mon)
        assertEquals(BlockDecision.Block(BlockReason.APP_LIMIT, 60), d)
    }

    @Test fun differentLimitsPerApp() {
        val limits = mapOf(limit(yt, 60), limit(insta, 45))
        val u = usage(100, yt to 50, insta to 50)
        assertEquals(BlockDecision.Allow, eval(yt, u, limits, global.copy(enabled = false), mon))
        assertTrue(eval(insta, u, limits, global.copy(enabled = false), mon) is BlockDecision.Block)
    }

    @Test fun blockedDayBlocksImmediately() {
        val limits = mapOf(limit(yt, 60, setOf(DayOfWeek.SATURDAY)))
        assertEquals(BlockDecision.Allow, eval(yt, usage(0), limits, global, DayOfWeek.FRIDAY))
        assertEquals(BlockDecision.Block(BlockReason.BLOCKED_DAY, 0), eval(yt, usage(0), limits, global, DayOfWeek.SATURDAY))
    }

    @Test fun globalThresholdLocksListedApps() {
        val tg = "org.telegram.messenger"
        assertEquals(BlockDecision.Allow, eval(tg, usage(44), emptyMap(), global, mon))
        for (p in listOf(tg, "com.android.chrome", "com.netflix.mediaclient", "com.fusionmedia.investing",
            "com.spotify.music", "com.sec.android.app.sbrowser")) {
            assertEquals(BlockDecision.Block(BlockReason.GLOBAL_THRESHOLD, 45), eval(p, usage(45), emptyMap(), global, mon))
        }
    }

    @Test fun whatsAppAndCallsNeverBlocked() {
        val huge = usage(600, "com.whatsapp" to 600)
        val rules = mapOf(limit("com.whatsapp", 1))
        assertEquals(BlockDecision.Allow, eval("com.whatsapp", huge, rules, global, mon))
        assertEquals(BlockDecision.Allow, eval("com.samsung.android.dialer", huge, emptyMap(), global, mon))
        assertEquals(BlockDecision.Allow, eval("com.samsung.android.incallui", huge, emptyMap(), global, mon))
    }

    @Test fun unlistedAppAllowedAfterThreshold() {
        assertEquals(BlockDecision.Allow, eval("com.duolingo", usage(300), emptyMap(), global, mon))
    }

    @Test fun globalRuleCanBeDisabled() {
        assertEquals(BlockDecision.Allow,
            eval("org.telegram.messenger", usage(300), emptyMap(), global.copy(enabled = false), mon))
    }

    @Test fun disabledAppRuleIgnored() {
        val l = mapOf(yt to AppLimit(yt, yt, 1, enabled = false))
        assertEquals(BlockDecision.Allow, eval(yt, usage(10, yt to 10), l, global, mon))
    }

    @Test fun remainingTimeUsesTheStricterRule() {
        val tg = "org.telegram.messenger"
        assertEquals(15 * min, eval.remainingMs(tg, usage(30), emptyMap(), global, mon))
        val l = mapOf(limit(tg, 60))
        assertEquals(5 * min, eval.remainingMs(tg, usage(40, tg to 10), l, global, mon))
        assertNull(eval.remainingMs("com.duolingo", usage(10), emptyMap(), global, mon))
        assertNull(eval.remainingMs("com.whatsapp", usage(10), emptyMap(), global, mon))
    }
}
